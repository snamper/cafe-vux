<template>
    <div class="logo-wrapper">
        <img src="../../../static/img/logo.jpg" width="100%" height="auto">
    </div>
</template>

<script type="text/ecmascript-6">
export default {
};
</script>

<style lang="stylus" rel="stylesheet/stylus">
.logo-wrapper
    img
        width 100%
        height auto
</style>
